import logo from './logo.svg';
import './App.css';



function MyApp() {
  return (
	<div className='entryPoint'>
		<p>React Portfolio App</p>
	</div>
	);
}

export default MyApp;
